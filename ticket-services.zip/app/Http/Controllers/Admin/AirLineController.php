<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Admin\AirLine;

class AirLineController extends Controller
{
    public function index(){
        return view('Admin.airline.list');
    }

    public function create(){
        return view('Admin.airline.add');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'code' => 'required|string|max:50',
            'logo' => 'nullable|image|mimes:png,jpg,jpeg|max:2048',
        ]);

        $logoPath = null;

        if ($request->hasFile('logo')) {
            $logoPath = $request->file('logo')->store('airlines', 'public');
        }

        Airline::create([
            'name' => $request->name,
            'code' => $request->code,
            'logo' => $logoPath,
            'status' => $request->status,
        ]);

         return response()->json([
                'success' => true,
                'message' => 'AirLine created successfully',
            ], 201);
    }


    public function edit(AirLine $airline){
        return view('Admin.airline.edit', compact('airline'));
    }

    public function update(Request $request){

        AirLine::find($request->id)->update([
            'name' => $request->name,
            'code' => $request->code,
            'status' => $request->status1,
        ]);

         return response()->json([
                'success' => true,
                'message' => 'AirLine updated successfully',
            ], 201);
    }
}
