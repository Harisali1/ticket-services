<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class AirLineStoreRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name'       => ['required', 'string', 'max:255'],
            'code'       => ['required', 'string', 'max:50'],
            'logo'       => ['required', 'file', 'mimes:png,jpg,jpeg', 'max:5120'], // 5MB
        ];
    }

    public function messages(): array
    {
        return [
            'name.required'      => 'Airline name is required',
            'code.required'      => 'Code is required',
            'logo.required'       => 'logo is required.',
            'logo.mimes'          => 'Only JPG, PNG, or JPEG files are allowed.',
            'logo.max'            => 'Logo must not exceed 5MB.',
        ];
    }
}
