<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;
use App\Enums\UserStatus;
use App\Models\Admin\Booking;
use App\Models\Admin\Payment;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_type_id',
        'name',
        'email',
        'phone_no',
        'password',
        'status',
        'created_by',
        'show_pass'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'status' => UserStatus::class,
    ];

    public function agency(){
        return $this->hasOne(User::Class);
    }

    public function getRemainingBalanceAttribute(){
        $balance = Payment::where('created_by', auth()->user()->id)
        ->where('is_approved', 0)
        ->sum('amount');
        return $balance;
    }

    public function payments()
    {
        return $this->hasMany(Payment::class, 'created_by');
    }

    public function getPaidBalanceAttribute()
    {
        return $this->payments()->where('status', 3)->sum('amount');
    }

    public function getRemainBalanceAttribute()
    {
        return $this->payments()->where('is_approved', 0)->sum('amount');
    }

}
