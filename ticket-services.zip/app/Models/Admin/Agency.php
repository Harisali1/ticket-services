<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Enums\AgencyStatus;
use App\Models\User;

class Agency extends Model
{
    use HasFactory;

    protected $guarded = [];

    protected $casts = [
        'status' => AgencyStatus::class,
    ];

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function getCreatedDateAttribute()
    {
        return \Carbon\Carbon::parse($this->created_at)->format('d-M-y H:i');
    }

}
