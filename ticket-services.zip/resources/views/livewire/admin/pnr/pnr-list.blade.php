<div class="container py-4">
    <!-- Header -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h4">Pnr List</h1>

        <div class="d-flex align-items-center gap-2">
            <a href="{{ route('admin.pnr.create') }}" class="btn btn-dark">
                + Create Pnr
            </a>

            <!-- Filter button triggers offcanvas -->
            <button class="btn btn-outline-secondary" type="button" data-bs-toggle="offcanvas" data-bs-target="#filterSidebar">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-funnel" viewBox="0 0 16 16">
                  <path d="M1.5 1.5a.5.5 0 0 1 .5-.5h12a.5.5 0 0 1 .4.8L10 7.7v5.6a.5.5 0 0 1-.757.429L7 12.101l-2.243 1.628A.5.5 0 0 1 4 12.3V7.7L1.1 2.3a.5.5 0 0 1 .4-.8z"/>
                </svg>
            </button>
        </div>
    </div>

    <!-- Filter Sidebar (Bootstrap Offcanvas) -->
    <div class="offcanvas offcanvas-end" tabindex="-1" id="filterSidebar">
        <div class="offcanvas-header">
            <h5 class="offcanvas-title">Filters</h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas"></button>
        </div>
        <div class="offcanvas-body">
            <div class="mb-3">
                <label class="form-label">Pnr No</label>
                <input type="text" wire:model.defer="filters.pnr_no" class="form-control" placeholder="Pnr No #">
            </div>

            <div class="mb-3">
                <label class="form-label">AirLine</label>
                <select wire:model.defer="filters.airline_id" class="form-select">
                    <option value="">Select AirLine</option>
                    <option value="1">Pending</option>
                    <option value="2">Approved</option>
                    <option value="3">Suspended</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Status</label>
                <select wire:model.defer="filters.status" class="form-select">
                    <option value="">Select</option>
                    <option value="1">Pending</option>
                    <option value="2">Approved</option>
                    <option value="3">Suspended</option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Created Date</label>
                <div class="row g-2">
                    <div class="col">
                        <input type="date" wire:model.defer="filters.from" class="form-control">
                    </div>
                    <div class="col">
                        <input type="date" wire:model.defer="filters.to" class="form-control">
                    </div>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button wire:click="applyFilters" data-bs-dismiss="offcanvas" class="btn btn-dark flex-fill">Search</button>
                <button wire:click="resetFilters" data-bs-dismiss="offcanvas" class="btn btn-outline-secondary flex-fill">Cancel</button>
            </div>
        </div>
    </div>

    <!-- Stats -->
    <div class="row mb-4">
        @foreach($stats as $label => $count)
            <div class="col-12 col-sm-6 col-lg-3 mb-3">
                <div class="card border">
                    <div class="card-body">
                        <p class="text-muted mb-1">{{ ucfirst($label) }}</p>
                        <h3 class="card-title">{{ $count }}</h3>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    <!-- Per Page Selector -->
    <div class="mb-3">
        <select wire:model.live="perPage" class="form-select w-auto">
            <option value="2">2</option>
            <option value="25">25</option>
            <option value="50">50</option>
        </select>
    </div>

    <!-- Table -->
    <div class="table-responsive mb-4">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th><input type="checkbox"></th>
                    <th>Pnr No #</th>
                    <th>AirLine</th>
                    <th>Departure Date/Time</th>
                    <th>Arrival Date/Time</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @forelse($pnrs as $pnr)
                    <tr>
                        <td><input type="checkbox"></td>
                        <td>{{ $pnr->pnr_no }}</td>
                        <td>{{ $pnr->airline->name }}</td>
                        <td>{{ $pnr->departure_date }}</td>
                        <td>{{ $pnr->arrival_date }}</td>
                        <td>
                            <span class="{{ $pnr->status->color() }}">
                                {{ $pnr->status->label() }}
                            </span>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button class="btn btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    ⋮
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><a class="dropdown-item" href="{{ route('admin.pnr.edit', $pnr->id) }}">Edit</a></li>
                                    <li>
                                       <button class="dropdown-item" wire:click="openPutOnSale({{ $pnr->id }})">
                                            Put on sale
                                        </button>
                                    </li>
                                </ul>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">
                            No agencies found
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
<div wire:ignore.self class="modal fade" id="putOnSaleModal" tabindex="-1">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">

                <!-- Header -->
                <div class="modal-header border-0">
                    <h5 class="modal-title fw-semibold">Put on sale</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <!-- Body -->
                <div class="modal-body pt-0">

                    <p class="text-muted mb-4">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                    </p>

                    <h6 class="fw-semibold mb-3">Seat Details</h6>

                    <div class="border rounded mb-4">
                        <div class="d-flex justify-content-between p-3 border-bottom">
                            <span>Total Seats</span>
                            <strong>{{ $selectedPnr->total_seats ?? 0 }}</strong>
                        </div>
                        <div class="d-flex justify-content-between p-3 border-bottom">
                            <span>Sold Seats</span>
                            <strong>{{ $selectedPnr->sold_seats ?? 0 }}</strong>
                        </div>
                        <div class="d-flex justify-content-between p-3 border-bottom">
                            <span>On Sale Seats</span>
                            <strong>{{ $selectedPnr->on_sale_seats ?? 0 }}</strong>
                        </div>
                        <div class="d-flex justify-content-between p-3">
                            <span>Available Seats</span>
                            <strong>{{ $selectedPnr->available_seats ?? 0 }}</strong>
                        </div>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Seats</label>
                            <select class="form-select" wire:model="seats">
                                <option value="">Select</option>
                                @for($i = 1; $i <= ($selectedPnr->available_seats ?? 0); $i++)
                                    <option value="{{ $i }}">{{ $i }}</option>
                                @endfor
                            </select>
                            @error('seats') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">Price *</label>
                            <input type="number" class="form-control"
                                   wire:model="price"
                                   placeholder="Enter price">
                            @error('price') <small class="text-danger">{{ $message }}</small> @enderror
                        </div>
                    </div>

                </div>

                <!-- Footer -->
                <div class="modal-footer border-0">
                    <button class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button class="btn btn-dark" wire:click="saveSale">
                        Save
                    </button>
                </div>

            </div>
        </div>
    </div>
    <!-- Pagination -->
    <div>
        {{ $pnrs->links() }}
    </div>
</div>
<!-- ================== MODAL ================== -->
    



