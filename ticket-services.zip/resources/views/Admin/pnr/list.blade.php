@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.pnr.pnr-list')
@endsection

@section('scripts')
@endsection




