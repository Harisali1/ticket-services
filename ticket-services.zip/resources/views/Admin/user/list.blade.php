@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.user.user-list')
@endsection

@section('scripts')
@endsection




