@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.aline.aline-list')
@endsection

@section('scripts')
@endsection




