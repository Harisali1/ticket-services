@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.airline.airline-list')
@endsection

@section('scripts')
@endsection




