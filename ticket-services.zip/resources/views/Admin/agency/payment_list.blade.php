@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.agency.agency-payment-list')
@endsection

@section('scripts')
@endsection




