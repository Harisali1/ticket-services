@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.agency.agency-list')
@endsection

@section('scripts')
@endsection




