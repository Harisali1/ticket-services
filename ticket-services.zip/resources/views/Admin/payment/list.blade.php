@extends('Admin.layouts.main')

@section('styles')

@endsection

@section('content')
    @livewire('admin.payment.payment-list')
@endsection

@section('scripts')

@endsection




