@extends('Admin.layouts.main')

@section('styles')

@endsection

@section('content')
    @livewire('admin.booking.booking-list')
@endsection

@section('scripts')
@endsection




