@extends('Admin.layouts.main')

@section('styles')
<style>
    .select2-container .select2-selection--single {
        height: 38px;
    }
    .select2-selection__rendered {
        line-height: 34px !important;
    }
    .select2-selection__arrow {
        height: 38px;
    }
    .type-style {
        margin-left: 25px;
    }
    .table-scroll {
        max-height: 500px;
        overflow-x: auto;
    }

    .table-scroll thead th {
        position: sticky;
        top: 0;
        z-index: 2;
        background: #f8f9fa;
    }

</style>
@endsection

@section('content')
<div class="container">
    <hr>

    <div class="card p-4">

        <form method="POST" action="{{ route('admin.booking.create') }}">
            @csrf

            <h5 class="mb-3">Search Flight</h5>
            <hr>

            <!-- Trip Type -->
            <div class="col-md-3 mb-3">
                <label class="me-3">
                    <input type="radio" name="trip_type" value="one_way" {{ request('trip_type') === 'one_way' ? 'checked' : '' }}>
                    One Way
                </label>

                <label class="type-style">
                    <input type="radio" name="trip_type" value="return" {{ request('trip_type', 'return') === 'return' ? 'checked' : '' }}>
                    Return
                </label>
            </div>

            <hr>

            <div class="row g-3">

                <div class="col-md-3">
                    <label class="form-label text-muted">Departure</label>
                    <select class="form-select" name="departure_id" id="departure_id" required>
                        <option value="">Select Departure</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label text-muted">Arrival</label>
                    <select class="form-select" name="arrival_id" id="arrival_id" required>
                        <option value="">Select Arrival</option>
                    </select>
                </div>

                <div class="col-md-2">
                    <label class="form-label text-muted">Departure Date</label>
                    <input type="date"
                           class="form-control"
                           name="departure_date"
                           id="departure_date"
                           value="{{ old('departure_date', request('departure_date')) }}"
                           required>
                </div>

                <div class="col-md-2" id="arrival-date-wrapper">
                    <label class="form-label text-muted">Arrival Date</label>
                    <input type="date"
                           class="form-control"
                           name="arrival_date"
                           id="arrival_date"
                           value="{{ old('arrival_date', request('arrival_date')) }}">
                </div>

                <div class="col-md-2 align-self-end">
                    <button type="submit" class="btn btn-dark w-100">
                        Search
                    </button>
                </div>

            </div>
        </form>

        @if($showPnrSearch)
            <livewire:admin.pnr.search-pnr :initialFilters="$initialFilters" />
        @endif

    </div>
</div>
@endsection

@section('scripts')
<script>
    $(document).ready(function () {

        /* ===============================
        Select2
        =============================== */
        $("#departure_id").select2({
            placeholder: "Search Departure",
            minimumInputLength: 2,
            ajax: {
                url: "{{ route('search.airport') }}",
                dataType: "json",
                delay: 250,
                processResults: function (data) {
                    return {
                        results: data.map(item => ({
                            id: item.id,
                            text: item.label
                        }))
                    };
                }
            }
        });

        $("#arrival_id").select2({
            placeholder: "Search Arrival",
            minimumInputLength: 2,
            ajax: {
                url: "{{ route('search.airport') }}",
                dataType: "json",
                delay: 250,
                processResults: function (data) {
                    return {
                        results: data.map(item => ({
                            id: item.id,
                            text: item.label
                        }))
                    };
                }
            }
        });

        /* ===============================
        Trip Type Logic
        =============================== */
        const arrivalWrapper = document.getElementById('arrival-date-wrapper');
        const arrivalDate    = document.getElementById('arrival_date');

        function toggleArrivalDate() {
            const type = document.querySelector('input[name="trip_type"]:checked').value;

            if (type === 'one_way') {
                arrivalDate.required = false;
                arrivalDate.value = '';
                arrivalWrapper.classList.add('d-none');
            } else {
                arrivalDate.required = true;
                arrivalWrapper.classList.remove('d-none');
            }
        }

        document.querySelectorAll('input[name="trip_type"]').forEach(radio => {
            radio.addEventListener('change', toggleArrivalDate);
        });

        // Initial load
        toggleArrivalDate();

        
        function setSelect2Value(selector, id, text) {
            if (id && text) {
                const option = new Option(text, id, true, true);
                $(selector).append(option).trigger('change');
            }
        }

        setSelect2Value(
            '#departure_id',
            $('#selected_departure_id').val(),
            $('#selected_departure_text').val()
        );

        setSelect2Value(
            '#arrival_id',
            $('#selected_arrival_id').val(),
            $('#selected_arrival_text').val()
        );
    });

    function selectPNRBooking(id){
        let modal = new bootstrap.Modal(document.getElementById('searchPnrSeatModal'));
        document.getElementById('pnr_id').value = id;
        modal.show();
    }

    
    document.addEventListener('DOMContentLoaded', function () {

        // Re-bind after Livewire DOM updates
        Livewire.hook('message.processed', () => {
            bindSeatForm();
        });

        bindSeatForm();

        function bindSeatForm() {

            const form = document.getElementById("pnr-select-seat");
            if (!form || form.dataset.bound) return;

            form.dataset.bound = "true"; // prevent multiple bindings

            form.addEventListener("submit", function (e) {
                e.preventDefault();

                function showError(message) {
                    Swal.fire({
                        toast: true,
                        position: "top-end",
                        icon: "error",
                        title: message,
                        showConfirmButton: false,
                        timer: 2500
                    });
                }

                const seat = document.getElementById("seat")?.value.trim();

                if (!seat) {
                    showError("Seat is required");
                    return;
                }

                Swal.fire({
                    title: "Processing...",
                    text: "Please wait",
                    didOpen: () => Swal.showLoading()
                });

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': document
                            .querySelector('meta[name="csrf-token"]')
                            ?.getAttribute('content')
                    }
                });

                $.ajax({
                    url: "{{ route('admin.booking.seats.availability') }}",
                    method: "POST",
                    data: $(form).serialize(),
                    dataType: 'json',
                    success: function (data) {
                        Swal.close();

                        if (data.code === 2) {
                            showError(data.message);
                            return;
                        }

                        // ✅ allow actual submit if OK
                        if (data.code === 1) {
                            form.submit();
                        }
                    },
                    error: function (xhr) {
                        Swal.close();
                        showError(xhr.responseJSON?.message || 'Something went wrong');
                    }
                });
            });
        }
    });

</script>
@endsection




