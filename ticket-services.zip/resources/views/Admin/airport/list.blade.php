@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.airport.airport-list')
@endsection

@section('scripts')
@endsection




