@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.notification.notification-list')
@endsection

@section('scripts')
@endsection




