@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.role.role-list')
@endsection

@section('scripts')
@endsection




