@extends('Admin.layouts.main')

@section('styles')
@endsection

@section('content')
    @livewire('admin.news.news-list')
@endsection

@section('scripts')
@endsection




