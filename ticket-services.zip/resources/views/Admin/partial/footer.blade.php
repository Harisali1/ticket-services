<footer class="page-footer fixed-footer pt-0">
    <div class="container">
        <div class="text-center text-muted">
            <strong>Divine Travel</strong> (IATA Authorized Agent) |
            P.IVA 02403080506 <br>
            © 2026 Divine Travel |
            <a href="#" class="text-decoration-none">Privacy Policy</a> |
            <a href="mailto:sales@bookingtravel.it" class="text-decoration-none">
                sales@bookingtravel.it
            </a>
        </div>
    </div>
</footer>
