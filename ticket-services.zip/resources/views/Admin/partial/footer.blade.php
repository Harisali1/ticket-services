<footer class="w-full border-t bg-white py-4 px-6 text-sm text-gray-600 flex justify-between items-center">
    <p>© 2025 Airline Management System. All rights reserved.</p>

    <div class="flex items-center gap-4">
        <a href="#" class="hover:text-gray-800">Privacy Policy</a>
        <a href="#" class="hover:text-gray-800">Terms</a>
        <a href="#" class="hover:text-gray-800">Support</a>
    </div>
</footer>
