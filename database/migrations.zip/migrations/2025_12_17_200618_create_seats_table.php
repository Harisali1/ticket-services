<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('seats', function (Blueprint $table) {
            $table->id();
            $table->integer('pnr_id');
            $table->boolean('is_sold')->default(0);
            $table->boolean('is_sale')->default(0);
            $table->boolean('is_reserved')->default(0);
            $table->boolean('is_available')->default(1);
            $table->boolean('is_cancel')->default(0);
            $table->string('price');
            $table->text('comment')->nullable();
            $table->integer('created_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('seats');
    }
};
